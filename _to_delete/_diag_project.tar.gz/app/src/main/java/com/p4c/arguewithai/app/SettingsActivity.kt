package com.p4c.arguewithai.app

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Switch
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import com.p4c.arguewithai.R

/**
 * 관리자 페이지. MainActivity에서 비밀번호 확인 후에만 진입한다.
 * 실험이 끝난 뒤 참여자의 PIP 설정을 원래대로 되돌릴 때도 여기서 처리한다.
 */
class SettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_settings)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            finish()
        }

        val switchDebugOverlay = findViewById<Switch>(R.id.switchDebugOverlay)
        switchDebugOverlay.isChecked = DebugOverlayPrefs.isEnabled(this)
        switchDebugOverlay.setOnCheckedChangeListener { _, isChecked ->
            DebugOverlayPrefs.setEnabled(this, isChecked)
        }

        // 실험 종료 후 PIP 설정 원래대로 되돌리기
        findViewById<Button>(R.id.btnRestorePipYoutube).setOnClickListener {
            OnboardingPrefs.openPipSettingsForApp(this, "com.google.android.youtube")
        }
        findViewById<Button>(R.id.btnRestorePipInstagram).setOnClickListener {
            OnboardingPrefs.openPipSettingsForApp(this, "com.instagram.android")
        }
    }
}
