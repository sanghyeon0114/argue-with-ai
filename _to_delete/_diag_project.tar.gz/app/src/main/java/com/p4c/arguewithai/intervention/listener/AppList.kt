package com.p4c.arguewithai.intervention.listener

enum class SocialMediaApp(val pkg: String, val label: String) {
    INSTAGRAM("com.instagram.android", "Instagram"),
    YOUTUBE("com.google.android.youtube", "youtube"),
    SYSTEM("com.android.systemui", "system"),
    INTERVENTION("com.p4c.arguewithai", "arguewithai"),
    NOT_DETECTION("not.detection", "notDetection"),
    NONE("none", "none");

    companion object {
        fun find(pkg: String): SocialMediaApp {
            return entries.find { it != NONE && it.pkg == pkg } ?: NONE
        }
    }
}
