package com.p4c.arguewithai.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.content.edit
import androidx.core.net.toUri
import com.p4c.arguewithai.platform.accessibility.MyAccessibilityService

/**
 * Main 진입 전 필수 설정(온보딩) 단계들의 완료 여부를 확인/기록하는 헬퍼.
 *
 * - 이름: 로컬 캐시(participant_name)로 판단. Firestore 동기화는 각 화면에서 별도 처리한다.
 * - 오버레이 / 접근성: 별도 저장 없이 OS 상태를 그때그때 조회한다.
 * - PIP: OS에 상태를 조회할 수 있는 공개 API가 없어서, 사용자가 "완료" 버튼을
 *   눌렀는지(pip_setup_confirmed)로 판단한다.
 * - 개입 타입: intervention_type 값이 저장돼 있는지로 판단한다.
 *   (주의: "app_prefs" / "intervention_type" 키는 Prompt.kt에서도 그대로 읽으므로 이름을 바꾸면 안 된다)
 */
object OnboardingPrefs {
    private const val PREFS = "app_prefs"
    private const val KEY_PARTICIPANT_NAME = "participant_name"
    private const val KEY_PIP_CONFIRMED = "pip_setup_confirmed"
    private const val KEY_INTERVENTION_TYPE = "intervention_type"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getCachedName(context: Context): String? =
        prefs(context).getString(KEY_PARTICIPANT_NAME, null)?.takeIf { it.isNotBlank() }

    fun setCachedName(context: Context, name: String) {
        prefs(context).edit { putString(KEY_PARTICIPANT_NAME, name) }
    }

    fun isOverlayGranted(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun isAccessibilityGranted(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val target = ComponentName(context, MyAccessibilityService::class.java)
        return enabled.any {
            val s = it.resolveInfo.serviceInfo
            s.packageName == target.packageName && s.name == target.className
        }
    }

    fun isPipConfirmed(context: Context): Boolean = prefs(context).getBoolean(KEY_PIP_CONFIRMED, false)

    fun setPipConfirmed(context: Context, confirmed: Boolean) {
        prefs(context).edit { putBoolean(KEY_PIP_CONFIRMED, confirmed) }
    }

    fun getInterventionType(context: Context): Int? {
        val value = prefs(context).getInt(KEY_INTERVENTION_TYPE, -1)
        return value.takeIf { it in 0..2 }
    }

    fun setInterventionType(context: Context, type: Int) {
        prefs(context).edit { putInt(KEY_INTERVENTION_TYPE, type) }
    }

    /** 5개 온보딩 단계(이름/오버레이/접근성/PIP/개입 타입)가 모두 끝났는지 */
    fun isOnboardingComplete(context: Context): Boolean {
        return getCachedName(context) != null &&
            isOverlayGranted(context) &&
            isAccessibilityGranted(context) &&
            isPipConfirmed(context) &&
            getInterventionType(context) != null
    }

    fun requestOverlayPermission(activity: Activity) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            "package:${activity.packageName}".toUri()
        )
        activity.startActivity(intent)
    }

    fun openAccessibilitySettings(activity: Activity) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { activity.startActivity(intent) }
    }

    /** 실험 시작 시 PIP 권한을 끄기 위해, 그리고 실험 종료 후 되돌리기 위해 동일하게 사용한다. */
    fun openPipSettingsForApp(context: Context, packageName: String) {
        try {
            val intent = Intent("android.settings.PICTURE_IN_PICTURE_SETTINGS").apply {
                data = "package:$packageName".toUri()
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                "package:$packageName".toUri()
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallback)
        }
    }
}
