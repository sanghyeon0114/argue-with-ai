package com.p4c.arguewithai.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import com.p4c.arguewithai.R
import com.p4c.arguewithai.repository.profiles.FirestoreUserRepository

/**
 * Main 진입 전에 반드시 끝내야 하는 5단계를 순서대로 보여주는 온보딩 화면.
 * 1) 이름 입력 -> 2) 오버레이 권한 -> 3) 접근성 서비스 -> 4) PIP 설정 -> 5) 개입 타입 설정
 *
 * 각 단계는 완료 여부를 그때그때(OnboardingPrefs) 다시 확인해서, 아직 끝나지 않은
 * 첫 단계를 보여준다. 시스템 설정 화면에 갔다가 돌아오면 onResume에서 자동으로
 * 다음 단계로 넘어간다.
 */
class OnboardingActivity : ComponentActivity() {

    private val userRepo by lazy { FirestoreUserRepository() }

    private lateinit var stepName: LinearLayout
    private lateinit var stepOverlay: LinearLayout
    private lateinit var stepAccessibility: LinearLayout
    private lateinit var stepPip: LinearLayout
    private lateinit var stepType: LinearLayout
    private lateinit var tvStepProgress: TextView
    private lateinit var tvAccessibilityStatus: TextView

    private val steps by lazy { listOf(stepName, stepOverlay, stepAccessibility, stepPip, stepType) }

    // 이름 로컬 캐시가 없을 때 Firestore 조회가 끝나기 전까지는 단계 판정을 미룬다.
    private var nameCheckDone = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_onboarding)

        stepName = findViewById(R.id.stepName)
        stepOverlay = findViewById(R.id.stepOverlay)
        stepAccessibility = findViewById(R.id.stepAccessibility)
        stepPip = findViewById(R.id.stepPip)
        stepType = findViewById(R.id.stepType)
        tvStepProgress = findViewById(R.id.tvStepProgress)
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)

        setupNameStep()
        setupOverlayStep()
        setupAccessibilityStep()
        setupPipStep()
        setupTypeStep()

        if (OnboardingPrefs.getCachedName(this) != null) {
            nameCheckDone = true
        } else {
            userRepo.getUserName { name ->
                if (!name.isNullOrBlank()) {
                    OnboardingPrefs.setCachedName(this, name)
                }
                nameCheckDone = true
                runOnUiThread {
                    if (!isFinishing) showCurrentStep()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (nameCheckDone) {
            showCurrentStep()
        }
    }

    private fun setupNameStep() {
        val etNameInput = findViewById<EditText>(R.id.etNameInput)
        OnboardingPrefs.getCachedName(this)?.let { etNameInput.setText(it) }

        findViewById<Button>(R.id.btnSaveName).setOnClickListener {
            val name = etNameInput.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            OnboardingPrefs.setCachedName(this, name)
            userRepo.setUserName(name) { ok ->
                if (!ok) {
                    runOnUiThread {
                        Toast.makeText(this, "❌ 서버 저장 실패 (네트워크 확인). 이름은 우선 저장하고 계속 진행합니다.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            showCurrentStep()
        }
    }

    private fun setupOverlayStep() {
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            OnboardingPrefs.requestOverlayPermission(this)
        }
    }

    private fun setupAccessibilityStep() {
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            OnboardingPrefs.openAccessibilitySettings(this)
        }
    }

    private fun setupPipStep() {
        findViewById<Button>(R.id.btnPipYoutube).setOnClickListener {
            OnboardingPrefs.openPipSettingsForApp(this, "com.google.android.youtube")
        }
        findViewById<Button>(R.id.btnPipInstagram).setOnClickListener {
            OnboardingPrefs.openPipSettingsForApp(this, "com.instagram.android")
        }
        findViewById<Button>(R.id.btnPipDone).setOnClickListener {
            OnboardingPrefs.setPipConfirmed(this, true)
            showCurrentStep()
        }
    }

    private fun setupTypeStep() {
        val etTypeInput = findViewById<EditText>(R.id.etTypeInput)
        OnboardingPrefs.getInterventionType(this)?.let { etTypeInput.setText(it.toString()) }

        findViewById<Button>(R.id.btnSaveType).setOnClickListener {
            val typeInt = etTypeInput.text.toString().trim().toIntOrNull()
            if (typeInt != null && typeInt in 0..2) {
                OnboardingPrefs.setInterventionType(this, typeInt)
                showCurrentStep()
            } else {
                Toast.makeText(this, "❌ 0, 1, 2 중 하나만 입력해주세요.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * 순서대로 각 단계의 완료 여부를 확인해서 아직 끝나지 않은 첫 단계만 보여준다.
     * 5단계가 모두 끝나면 MainActivity로 넘어간다.
     */
    private fun showCurrentStep() {
        tvAccessibilityStatus.text =
            if (OnboardingPrefs.isAccessibilityGranted(this)) "상태: 활성화됨 ✅" else "상태: 비활성화됨 ❌"

        val stepIndex = when {
            OnboardingPrefs.getCachedName(this) == null -> 0
            !OnboardingPrefs.isOverlayGranted(this) -> 1
            !OnboardingPrefs.isAccessibilityGranted(this) -> 2
            !OnboardingPrefs.isPipConfirmed(this) -> 3
            OnboardingPrefs.getInterventionType(this) == null -> 4
            else -> -1
        }

        if (stepIndex == -1) {
            goToMain()
            return
        }

        steps.forEachIndexed { index, view ->
            view.visibility = if (index == stepIndex) View.VISIBLE else View.GONE
        }
        tvStepProgress.text = "${stepIndex + 1} / ${steps.size}"
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
